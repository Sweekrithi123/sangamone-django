from django.urls import path
from left_diamond import views

urlpatterns=[
    path("",views.diamondLeft,name="diamondleft")
    ]
