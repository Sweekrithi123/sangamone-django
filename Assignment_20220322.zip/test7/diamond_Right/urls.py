from django.urls import path
from diamond_Right import views

urlpatterns=[
    path("",views.diamondRight,name="diamondRight")
    ]
