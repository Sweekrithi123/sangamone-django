from django.urls import path
from diamond_full1 import views

urlpatterns=[
    path('',views.diamondFull1,name='diamondfull1')
    ]
