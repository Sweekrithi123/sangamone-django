from django.urls import path
from diamond_left1 import views

urlpatterns=[
    path('',views.diamondLeft1,name='diamondleft1')
    ]
