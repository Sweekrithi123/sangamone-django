from django.urls import path
from diamond_right1 import views

urlpatterns=[
    path('',views.diamondRight1,name='diamondright1')
    ]
