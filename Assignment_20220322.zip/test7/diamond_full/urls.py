from django.urls import path
from diamond_full import views

urlpatterns=[
    path("",views.diamondFull,name="diamondFull")
    ]
