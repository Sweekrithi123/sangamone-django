from django.urls import path
from factorial1 import views

urlpatterns = [
    path('', views.factorial1, name='factorial1'),
]
