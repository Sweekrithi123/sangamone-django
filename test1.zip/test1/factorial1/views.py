from django.shortcuts import render

def factorial1(request):
    num1=5
    fact=1
    for i in range(1,num1+1,1):
        fact=fact*i
    print ('factorial of', num1, '=',fact)
    return render(request, 'factorial1.html', {'message1':num1,'message2':fact})
