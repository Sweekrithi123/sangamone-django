from django.urls import path
from diamond_left import views

urlpatterns=[
    path("",views.diamondleft,name="diamondleft")
    ]
