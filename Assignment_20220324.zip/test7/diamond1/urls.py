from django.urls import path
from diamond1 import views

urlpatterns=[
    path('',views.diamonds,name='diamond1')
    ]
