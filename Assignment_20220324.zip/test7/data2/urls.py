from django.urls import path
from data2 import views
urlpatterns=[
    path("",views.data2,name="data2")
    ]
