from django.shortcuts import render
from data2.models import data

def data2(request):
    message1={}
    if request.method=="POST":
        if request.POST.get("input1"):
            d1=data()
            d1.name=request.POST.get("input1")
            d1.save()
            name1=data.objects.all()
            message1={
                "name":name1
                }
    return render(request,"data2.html",message1)
    
