from django.urls import path
from diamond2 import views

urlpatterns=[
    path('',views.diamonds,name='diamond2')
    ]
