from django.shortcuts import render
from diamond2.models import diamonds2

def diamonds(request):
    s1 = diamonds2.objects.all()
    d1 = {
        'name':s1
    }
    s3=str(d1)
    len1=len(s3)
    s2=" "
    output1=""
                
    for i in range(1,len1+1,1):
        output1=output1+str(s3[0:i])+"\n"
                
    for i in range(1,len1,1):
        output1=output1+str(s3[0:len1-i])+"\n"
    return render(request, 'diamond2.html',d1,{'message1':output1})

