from django.db import models

class diamonds2(models.Model):
    name=models.TextField()
