from django.shortcuts import render
from data1.models import data

def data1(request):
    name1=data.objects.all()
    message1={
        "name":name1
        }
    return render(request,"data1.html",message1)
    
