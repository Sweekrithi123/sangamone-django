from django.urls import path
from data1 import views
urlpatterns=[
    path("",views.data1,name="data1")
    ]
