from django.db import models

class data(models.Model):
    name=models.CharField(max_length=20)
