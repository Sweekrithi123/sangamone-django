"""test7 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('left/',include("diamond_left.urls")),
    path('right/',include("diamond_Right.urls")),
    path('full/',include("diamond_full.urls")),
    path('left1/',include("diamond_left1.urls")),
    path('right1/',include("diamond_right1.urls")),
    path('full1/',include("diamond_full1.urls")),
    path('diamond1/',include("diamond1.urls")),
    path('diamond2/',include("diamond2.urls")),
    path('data1/',include("data1.urls")),
    path('data2/',include("data2.urls")),


]
